package com.nhnacademy;

public class PositionalVector extends Vector {

    public PositionalVector(int dx, int dy) {
        super(dx, dy);
    }

}
